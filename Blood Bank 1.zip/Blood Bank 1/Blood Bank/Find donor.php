<?php
      session_start();
      if(!isset($_SESSION['userName']) && empty($_SESSION['userName'])){
            echo $_SESSION['userName'];
          header('location: index.php');  
          exit();
      }
?>

<!DOCTYPE html>
<title>Blood Bank</title>
<link rel="stylesheet"href="./css/Style.css">
<script src="script.js"></script>
<style>
    table, th, td {
    border-collapse: collapse;

    padding: 0px 20px 10px 10px;
}
.image{
  width: 500px;
    height: 250px;
    margin: 20px auto;
    box-sizing: border-box;
    overflow: hidden;
    /*box-shadow: 5px 5px 10px grey;*/
    padding-left: 30px;
}
a{
  color:black;
  font-weight: bold;
  font-size: 16px;

}
p{
  text-align: center;
}
a{
  color: white;
}
</style>
</head>
<body bgcolor="#424b5c">

<div  style="background-color: brown"style="border:solid black">

<a href="Features.php"> <img src="imagehome.jpg"  height="100px" width="120" style="padding:0px 0px    0px 0px;"></a>

  <a href="Donor.php"> <img src="Donor.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>


  <a href="request.php"> <img src="request.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
   
  

  <a href="Blood Bank.php"> <img src="Blood Bank Number.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>

<a href="Ambulance.php"> <img src="Ambulance.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
       

<a href="Who can donate.html"> <img src="wcd.png"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
      
  
</div>

<h1 align="center" style="color: white">Find Donar</h1>
<br>
<br>

<center>
<table>

<tr>
<td>
<a href="A+.php"> <img src="A+.jpg"  height="80px" width="120px"></a>
<p><a href="A+.php">A+</a> </p> 		

</td>
<td>
<a href="B+.php"> <img src="B+.jpg"  height="80px" width="120" t></a>
<p><a href="B+.php">B+</a> </p> 
</td>
<td>
<a href="AB+.php"> <img src="AB+.jpg"  height="80px" width="120" t></a>
<p><a href="AB+.php">AB+</a> </p> 
  
</td>
<td>
<a href="O+.php"> <img src="O+.jpg"  height="80px" width="120" t></a>
<p><a href="O+.php">O+</a> </p> 	
  
</td>
</tr>
<tr>
<td>
<a href="A-.php"> <img src="A-.jpg"  height="80px" width="120" t></a>
<p><a href="A-.php">A-</a> </p> 	
</td>
<td>
<a href="B-.php"> <img src="B-.jpg"  height="80px" width="120" t></a>
<p><a href="B-.php">B-</a> </p>		

</td>
<td>
<a href="AB-.php"> <img src="AB-.jpg"  height="80px" width="120" t></a>
<p><a href="AB-.php">AB-</a> </p> 		

</td>
<td>
<a href="O-.php"> <img src="O-.jpg"  height="80px" width="120" t></a>
<p><a href="O-.php">O-</a> </p> 		

</td>

</tr>
</table>
<br>
<br>
<br>
<br>
</center>

<table align="center">
<tr>
<p><br></p>
<th><a style="color:white" href="index.html"> LOG OUT</a></th>
</tr>

</table>



</body>

</html>

