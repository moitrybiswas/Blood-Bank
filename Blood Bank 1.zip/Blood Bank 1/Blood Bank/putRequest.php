<?php 
$pName=$_POST['pName'];
$pBloodGroup= $_POST['pBloodGroup'];
$pArea=$_POST['pArea'];
$pDistrict=$_POST['pDistrict'];
$hName=$_POST['hName'];
$otherInfo=$_POST['otherInfo'];
$mobile=$_POST['mobile'];
include 'connect.php';
$Myarray =  array();
$sql = "INSERT  INTO blood_request
        VALUES(DEFAULT,'$pName','$pBloodGroup','$pArea','$pDistrict','$hName','$mobile','$otherInfo');";
$result = mysqli_query($conn, $sql);
if ($result){
    $r = 1;
}
else{
    $r = 0;
}
array_push($Myarray,$r);
echo json_encode($Myarray);
?>