<?php
    include 'connect.php';
    session_start();
    $userName = $_SESSION['userName'];
    $area = $_POST['area'];
    $bGroup = $_POST['bloodGroup'];
    $district = $_POST['district'];
    $dateOfDonation = $_POST['dateOfDonation'];
    $mobile = $_POST['mobile'];
    $Myarray =  array();
    $sql= "INSERT  INTO donor_list
            VALUE('$userName','$bGroup','$area','$district','$mobile','$dateOfDonation');";
    $result = mysqli_query($conn, $sql);
    $r=0;
    if($result){
        $r=1;
    }
    array_push($Myarray,$r);
    echo json_encode($Myarray);
?>