<?php
    include 'connect.php';
    $userName = $_POST['userName'];
    $password = $_POST['password'];
    $Myarray =  array();
    $sql= "Select * from user_list where BINARY userName='".$userName."' and BINARY password='".$password."';";
    $result = mysqli_query($conn, $sql);
    if (!empty($result) && $result->num_rows > 0){
        session_start();
        $_SESSION['userName']=$userName; 
        $r = 1;
    }
    else{
        $r = 0;
    }
    array_push($Myarray,$r);
    echo json_encode($Myarray);
    // echo 1;