<?php 
function getAmbulanceDetails(){
    include 'connect.php';
     $sql = "SELECT ambulance_number, name, contact_number,district FROM ambulance";
    return mysqli_query($conn, $sql);
}
function getBloodBankDetails(){
    include 'connect.php';
     $sql = "SELECT  name,area, contact_number,district FROM blood_bank";
    return mysqli_query($conn, $sql);
}
function getDonors($bGroup){
    include 'connect.php';
     $sql = "SELECT  * FROM donor_list where blood_group='$bGroup'";
    return mysqli_query($conn, $sql);
}
?>