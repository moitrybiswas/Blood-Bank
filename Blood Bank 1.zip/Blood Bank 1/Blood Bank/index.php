<?php 
session_start();
session_destroy();
?>
<!DOCTYPE html>

<html>
    <head>
        <title>Blood Bank</title>
        <link rel="stylesheet"href="./css/Style.css">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
        <script src="script.js"></script>
        
        <body style="background-image: url('Background.jpg">
            <center>
            <div class="logform" >
              <form ><br>
                <p style="font-size: 25px"> Username:<input type="text" id="user name" value="Karim123"></p>
                <p style="font-size: 25px"> Password:<input type="password" id="pass" value="123"></p>
               
                <button id = "Button" type="button" value="login" onclick="login()" style="font-size: 18px">
                       <b> Log In </b>
                    </button>
                    </a>
                    <a href="create form.php" style="color: black"><b>Create an Account</b></a>
              </form> 
              <span style="color:black;"><b class="Note"><br>Note : </b>For Demo use following <br>username and password. <br/><b class="valid"style="color: black;">User Name : Blood<br/>Password : Bank</b></span> 
          
            </div>
          </center>
            
          </body>
          
          </html>
