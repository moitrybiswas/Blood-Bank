<?php
      session_start();
      if(!isset($_SESSION['userName']) && empty($_SESSION['userName'])){
            echo $_SESSION['userName'];
          header('location: index.php');  
          exit();
      }
?>
<html>

<head>
    <title>Blood Bank</title>
    <link rel="stylesheet" href="./css/Style.css">
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 50%;
            background-color: white;
            border: brown;
        }
        
        td,
        th {
            border: 1px solid brown;
            text-align: left;
            padding: 10px;
            color: brown;
        }
    </style>
</head>

<body bgcolor="#424b5c">

    <div style="background-color:brown" style="border:solid black">

        <a href="Features.php"> <img src="imagehome.jpg" height="100px" width="120" style="padding:0px 0px    0px 0px;"></a>

        <a href="Donor.php"> <img src="Donor.jpg" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>


        <a href="request.php"> <img src="request.jpg" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>



        <a href="Blood Bank.php"> <img src="Blood Bank Number.jpg" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>

        <a href="Ambulance.php"> <img src="Ambulance.jpg" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>


        <a href="Who can donate.html"> <img src="wcd.png" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>


    </div>
    <h1 align="center" style="color: white">Ambulance Numbers</h1>


    <form>
        <table align="center">
        <tr>
            <th>Name</th>
            <th>Ambulance Number</th>
            <th>District</th>
            <th>Contact</th>
        </tr>
        <?php
            require 'functions.php';
            $data = getAmbulanceDetails();
            if (mysqli_num_rows($data) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($data)) {
                  echo "<tr>
                  <td >".$row["name"]."</td>
                  <td >".$row["ambulance_number"]."</td>
                  <td >".$row["district"]."</td>
                  <td >".$row["contact_number"]."</td>
                  </tr>";
                }
              } else {
                echo "0 results";
              }
        ?>
           
            

        </table>
        <br>
        <br>
        <center>
            <tr>
                <th><a style="color:white" href="index.php"><b> LOG OUT</b></a></th>
            </tr>


</body>


</html>
