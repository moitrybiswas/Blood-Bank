<?php
      session_start();
      if(!isset($_SESSION['userName']) && empty($_SESSION['userName'])){
            echo $_SESSION['userName'];
          header('location: index.php');  
          exit();
      }
	  include 'connect.php';
	  $sql = "Select * from user_list where userName='".$_SESSION['userName']."';";
	  $result = mysqli_query($conn, $sql);
	  $row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<script src="script.js"></script>
  <style>
  .image{
			width: 500px;
      		height: 250px;
      		margin: 20px auto;
      		box-sizing: border-box;
      		overflow: hidden;
      		padding-left: 30px;
		}
  </style>
</head>
<body bgcolor="#424b5c">
  <div style="background-color: brown"style="border:solid black" >

	<a href="Features.php"> <img src="imagehome.jpg"  height="100px" width="120" style="padding:0px 0px    0px 0px;"></a>

	<a href="Donor.php"> <img src="Donor.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
  
  
	<a href="request.php"> <img src="request.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
	 
	
  
	<a href="Blood Bank.php"> <img src="Blood Bank Number.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
  
  <a href="Ambulance.php"> <img src="Ambulance.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
		 
  
  <a href="Who can donate.html"> <img src="wcd.png"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
		
			
	</div>
  <div class="image">
	<img src="index.jpg" width="450" height="200" style="padding:0px 0px 0px 0px;">
	</div>
	<h1 h1 style="text-align:center; color:white">Update Profile</h1>
	  <table align="center">
   <form action="">
  <table border="1" align="center" height="400px" width="400px" bgcolor="white" >
<tr>
<th style="color: black">Area</th>
<td><input type="text" placeholder="enter your area" value=<?php echo $row['userName']; ?> id="area" required/></td>
</tr>
<tr>
<th style="color: black">District</th>
<td><input type="text"placeholder="enter your district" value="Gazipur" id="district" required/></td>
</tr>

<tr>
<th style="color: black">Last date of Blood Donation</th>
<td><input type="date" id="dateOfDonation" required/></td>
</tr>

<tr>
<th style="color: black">Enter your mobile</th>
<td><input type="number" value="123" id="mobile" required/></td>
</tr>
<td height="50px" width="50px" colspan="2" align="right">
      <button type="Button" onclick="submitProfile() "/>
			Update</button>
<input type="reset" value="Reset"/>
</td>
</table>
</form>

<table align="center">
  <tr>
  	<p><br></p>
    <th><a style="color:white" href="index.php"> LOG OUT</a></th>
  </tr>

</table>

 
</body>
</html>