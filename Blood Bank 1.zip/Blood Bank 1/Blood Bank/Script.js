//login form
{/* <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script> */}
function login()
{
  var un=document.getElementById("user name").value;
  var pass=document.getElementById("pass").value;
  // console.log(un,pass);
  $.ajax({  
    type: 'POST',  
    url: 'loginCheck.php',
    data: { password : pass,
            userName : un
     },
     dataType:'json',
    success: function(data, status, xhr) {
       if(data[0]==1){
         alert("Logged in successfully.");
         window.location = "Features.php" ;
       }
      else
        alert("Password and Username don't match.");
    },
    error: function(req, err){ console.log('my message' + err + req); }
});
}
//for password maching
function passVarification(){
  var a=document.getElementById("password").value;
  var b=document.getElementById("rpassword").value;
  if(a!=b){
    alert("Invalide re-password");
    return;
  }
  var fName = document.getElementById("fName").value;
  var lName = document.getElementById("lName").value;
  var uName = document.getElementById("uName").value;
  var password = a;
  var email = document.getElementById("email").value;
  var mobile = document.getElementById("mobile").value;
  var address = document.getElementById("address").value;
  var DOB = document.getElementById("DOB").value;
  var e = document.getElementById("country");
  var country =  e.options[e.selectedIndex].text;
  var gender = document.getElementsByName('g');
  var uGender;
  for (var i = 0, length = gender.length; i < length; i++) {
    if (gender[i].checked) {
      uGender = gender[i].value;
      break;
    }
  }
  $.ajax({  
      type: 'POST',  
      url: 'createUser.php',
      data: {
        fName : fName,
        lName: lName,
        uName : uName,
        password:password,
        email:email,
        mobile:mobile,
        address:address,
        country:country,
        uGender:uGender,
        DOB:DOB
      },
      dataType:'json',
      success: function(data, status, xhr) {
        console.log(data);
        if(data[0]==1){
          alert("Registered in successfully.");
          window.location = "index.php" ;
        }
        // else
        //   alert("UserName already in use.");
      },
      error: function(req, err){ 
        console.log('my message ' + err + req); 
      }
  });
}
//donar submission
function submitButton()
{
  var bloodGroup = document.getElementById("bloodGroup").value;
  var area = document.getElementById("area").value;
  var district = document.getElementById("district").value;
  var mobile = document.getElementById("mobile").value;
  var lastDateOfDonation = document.getElementById("lastDate").value;
  console.log(bloodGroup,area,district,lastDateOfDonation);
  $.ajax({  
      type: 'POST',  
      url: 'putDonor.php',
      data: {
        bloodGroup:bloodGroup,
        mobile:mobile,
        area:area,
        dateOfDonation:lastDateOfDonation,
        district:district
      },
      dataType:'json',
      success: function(data, status, xhr) {
        console.log(data);
        if(data[0]==1){
          alert("Congratulations!!! You are become a Donor now ");
          window.location = "Features.php" ;
        }
        // else
        //   alert("UserName already in use.");
      },
      error: function(req, err){ 
        console.log('my message ' + err + req); 
      }
  });
}

//profile submission
function submitProfile()
{
  var dateOfDonation=document.getElementById("dateOfDonation").value;
  var mobile=document.getElementById("mobile").value;
  var area=document.getElementById("area").value;
  var district=document.getElementById("district").value;
 console.log(area,district,dateOfDonation,mobile);
 $.ajax({  
  type: 'POST',  
  url: 'loginCheck.php',
  data: { 
   },
   dataType:'json',
  success: function(data, status, xhr) {
     if(data[0]==1){
       alert("Logged in successfully.");
       window.location = "Features.php" ;
     }
    else
      alert("Password and Username don't match.");
  },
  error: function(req, err){ console.log('my message' + err + req); }
});
 
  // alert(" Your profile has been updated ");
}

//request submit 
function submitRequest()
{
  var pName=document.getElementById("pName").value;
  var pBloodGroup=document.getElementById("pBloodGroup").value;
  var pArea=document.getElementById("pArea").value;
  var pDistrict=document.getElementById("pDistrict").value;
  var hName=document.getElementById("hName").value;
  var otherInfo=document.getElementById("otherInfo").value;
  var mobile=document.getElementById("pMobile").value;
  // var area=document.getElementById("area").value;
  // var district=document.getElementById("district").value;
  console.log(pName,pBloodGroup,pArea,pDistrict,hName,otherInfo,mobile);
  $.ajax({  
    type: 'POST',  
    url: 'putRequest.php',
    data: { pName:pName,
            pBloodGroup:pBloodGroup,
            pArea:pArea,
            pDistrict:pDistrict,
            hName:hName,
            otherInfo:otherInfo,
            mobile:mobile
     },
     dataType:'json',
    success: function(data, status, xhr) {
      // console.log(status,xhr);
      
       if(data[0]==1){
        alert(" Your request has been accepted ");
        //  window.location = "Features.php" ;
       }
      else
        alert("Request failed.");
    },
    error: function(req, err){ console.log('my message' + err + req); }
  });
  //  alert("SDD");
  
  // window.location = "Features.html" ;
}

