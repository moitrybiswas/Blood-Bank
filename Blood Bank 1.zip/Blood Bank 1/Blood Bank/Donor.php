<?php
      session_start();
      if(!isset($_SESSION['userName']) && empty($_SESSION['userName'])){
            echo $_SESSION['userName'];
          header('location: index.php');  
          exit();
      }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Blood Bank</title>
        <link rel="stylesheet"href="./css/Style.css">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
        <script src="script.js"></script>
        <style >
            .image{
                        width: 500px;
                          height: 250px;
                          margin: 20px auto;
                          box-sizing: border-box;
                          overflow: hidden;
                          padding-left: 30px;
                    }
              </style>
            </head>
                <body bgcolor="#424b5c">
            
                <div  style="background-color:brown"style="border:solid black">
            
                  <a href="Features.php"> <img src="imagehome.jpg"  height="100px" width="120" style="padding:0px 0px    0px 0px;"></a>

                  <a href="Donor.php"> <img src="Donor.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
                
                
                  <a href="request.php"> <img src="request.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
                   
                  <a href="Blood Bank.php"> <img src="Blood Bank Number.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
                
                <a href="Ambulance.php"> <img src="Ambulance.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
                       
                
                <a href="Who can donate.html"> <img src="wcd.png"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
                      
                </div>
                <div class="image">
                <img src="index.jpg" width="450" height="200" style="padding:0px 0px 0px 0px;">
                </div>
              <h1 align="center" style="color: white">Be A Donar</h1>
            
              <table align="center">
               <form>
              <table border="1" align="center" height="400px" width="400px" bgcolor="white" >
            <tr>
            <th style="color: black">Blood Group</th>
            <td><input type="text"placeholder="your blood group" id="bloodGroup" value="A" required/></td>
            </tr>
            <tr>
            <th style="color: black">Area</th>
            <td><input type="text"placeholder=" enter your area" id="area" value="Uttara" required/></td>
            </tr>
            <tr>
            <th style="color: black">District</th>
            <td><input type="text"placeholder="enter your district" id="district" value="Dhaka" required/></td>
            </tr>
            
            <tr>
            <th style="color: black">Last date of Blood Donation</th>
            <td><input type="date" id="lastDate" required/></td>
            </tr>
            
            <tr>
            <th style="color: black">Enter your mobile</th>
            <td><input type="number" id="mobile"  value="0192123213" required/></td>
            </tr>
            <td height="50px" width="50px" colspan="2" align="right">
                <button type="Button" onclick="submitButton() "/>
                        Submit</button>
            <input type="reset" value="Reset"/>
            </td>
            </table>
            </form>
               <table align="center">
                <tr>
                    <p><br></p>
                  <th><a style="color:white" href="index.php"> LOG OUT</a></th>
                </tr>
               </table>
          </body>
    </head>
</html>