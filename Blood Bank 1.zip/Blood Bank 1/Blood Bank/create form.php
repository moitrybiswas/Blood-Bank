<!DOCTYPE html>
<html>
    <head>
        <title>Blood Bank</title>
        <link rel="stylesheet"href="./css/Style.css">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script> 
        <script src="script.js"></script>
    </head>
    <body>
        

        <body bgcolor="#424b5c" >
            <h2  align="center";>Registration Form</h2>
    
      <form action="">
      <table border="1" align="center" height="500px" width="500px" bgcolor="white" >
    <tr>
    <th style="color:black">Enter your first name</th>
    <td>
        <input type="text" name="fn"  maxlength="30" value="smgmail" title="enter your first name" placeholder="enter your first name" id="fName" required/>
    </td>
    </tr>
    <tr>
    <th style="color:black">Enter your last name</th>
    <td><input type="text"placeholder="enter your last name"  value="sam" id="lName" required/></td>
    </tr>
    
    <tr>
    <th style="color:black">Enter your user name</th>
    <td><input type="text"placeholder="Enter your user name" value="sm" id="uName" required/></td>
    </tr>
    
    <tr>
    <th style="color:black">Enter your password</th>
    <td><input type="password"  value="sm123" placeholder="Password....." id="password" required/></td>
    </tr>
    <tr>
    <th style="color:black">Re-Enter your password</th>
    <td><input type="password" value="sm123" id="rpassword" required/></td>
    </tr>
    <tr>
    <th style="color:black">Enter your email</th>
    <td><input type="email" id="email" value="sm@gmail.com" /></td>
    </tr>
    <tr>
    <th style="color:black">Enter your mobile</th>
    <td><input type="number" id="mobile" value="152478" required/></td>
    </tr>
    <tr>
    <th style="color:black">Enter your address</th>
    <td><textarea rows="8" cols="20" id="address" required> adress</textarea></td>
    </tr>
    <tr>
    <th style="color:black">Select your gender</th>
    <td style="color: black">
    male<input type="radio" name="g" value="male" required/>
    female<input type="radio" name="g" value="female" required/>
    </td>
    </tr>
    <tr>
    <th style="color:black">Select your Date Of Birth</th>
    <td><input type="date" id="DOB" required/></td>
    </tr>
    <tr>
    <th style="color:black">Select your Country</th>
    <td>
    <select  id="country" required>
    <option value="" selected="selected" disabled="disabled">Select your country</option>
    <option value="1">Bangladesh</option>
    <option value="2">India</option>
    <option value="3">Pakistan</option>
    <option value="4">SriLanka</option>
    <option value="5">Nepal</option>
    </select>
    </td>
    </tr>
    <tr>
    <td height="50px" width="50px" colspan="2" align="center">
        <button type="button" value="submit" onclick="passVarification()"/>
                Submit</button>
    <input type="reset" value="Reset"/>
    </td>
    
    </table>
    </form>
    
    
    
    </body>
    
    </html>