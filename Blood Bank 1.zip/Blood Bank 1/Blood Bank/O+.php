<?php
      session_start();
      if(!isset($_SESSION['userName']) && empty($_SESSION['userName'])){
            echo $_SESSION['userName'];
          header('location: index.php');  
          exit();
      }
?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 50%;
  background-color: white;
  border: brown;
}

td, th {
  border: 1px solid brown;
  text-align: left;
  padding: 10px;
}

</style>
</head>
<body>
  <div style="background-color: brown" style="border:solid black">

       <a href="Features.php"> <img src="imagehome.jpg"  height="100px" width="120" style="padding:0px 0px    0px 0px;"></a>

      <a href="Donor.php"> <img src="donor.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
     

      <a href="Find donor.php"> <img src="Find donor.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px; "></a>
       
      
    
      <a href="request.php"> <img src="request.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>

      <a href="Ambulance.php"> <img src="ambulance.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
        
    
     <a href="whoCanDonate.html"> <img src="wcd.png"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
        
      
  </div>

<h1 style="text-align:center; color:white">O+ Blood Donor</h1>

<table align="center">

    <tr>
        <th style="color: brown;">Name</th>
        <th style="color: brown;">Area</th>
        <th style="color: brown;">District</th>
        <th style="color: brown;">Contact</th>
        <th style="color: brown;">Last Donation</th>
      </tr>
      <?php
            require 'functions.php';
            $data = getDonors('O+');
            if (mysqli_num_rows($data) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($data)) {
                  echo "<tr>
                  <td >".$row["userName"]."</td>".
                  "<td>".$row["area"]."</td>".
                  "<td>".$row["district"]."</td>".
                  "<td>".$row["contact_number"]."</td>".
                  "<td>".$row["last_date_Of_blood_donation"]."</td>".
                  "</tr>";
                }
              }
        ?>
</table>

</body>
</html>