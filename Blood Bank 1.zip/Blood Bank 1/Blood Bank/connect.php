<?php 
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbName = "blood_bank";

    // Create connection
    $conn =  mysqli_connect($servername, $username, $password,$dbName);

    // Check connection

    if(!$conn){
        die("Connection Failed: ".mysqli_connect_error());
    }    