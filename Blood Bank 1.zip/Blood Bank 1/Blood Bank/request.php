<?php
session_start();
if (!isset($_SESSION['userName']) && empty($_SESSION['userName'])) {
  echo $_SESSION['userName'];
  header('location: index.php');
  exit();
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Blood Bank</title>
  <link rel="stylesheet" href="./css/Style.css">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
  <script src="script.js"></script>

  <style>
    table {
      border-collapse: collapse;
    }
  </style>
</head>

<body bgcolor="#424b5c">

  <div style="background-color: brown" style="border:solid black">

    <a href="Features.php"> <img src="imagehome.jpg" height="100px" width="120" style="padding:0px 0px    0px 0px;"></a>

    <a href="Donor.php"> <img src="donor.jpg" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>

    <a href="Find donor.php"> <img src="Find donor.jpg" height="100px" width="120" style="padding:0px 0px 0px 90px; "></a>

    <a href="Blood Bank.php"> <img src="Blood Bank Number.jpg" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>

    <a href="Ambulance.php"> <img src="ambulance.jpg" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>


    <a href="whoCanDonate.html"> <img src="wcd.png" height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>


  </div>

  <h1 align="center" style="color: white">Request For Blood</h1>
  <table align="center">
    <form action="index.html">
      <table border="1" align="center" height="400px" width="400px" bgcolor="white">
        <tr>
          <th style="color: black">Patient's Name</th>
          <td><input type="text" placeholder="patient's name" value="kadir" id="pName" required /></td>
        </tr>

        <tr>
          <th style="color: black">Blood Group</th>
          <td><input type="text" placeholder="blood group" value="A+" id="pBloodGroup" required /></td>
        </tr>
        <tr>
          <th style="color: black">Area</th>
          <td><input type="text" placeholder=" enter your area" value="Dhaka" id="pArea" required /></td>
        </tr>
        <tr>
          <th style="color: black">District</th>
          <td><input type="text" placeholder="enter your district" value="Dalas" id="pDistrict" required /></td>
        </tr>

        <tr>
          <th style="color: black">Hospitals Name</th>
          <td><input type="text" placeholder="hospitals name" value="medical hospital" id="hName" required /></td>
        </tr>
        <tr>
          <th style="color: black">Contact Number</th>
          <td><input type="number" value="01751321" id="pMobile" required /></td>
        </tr>
        <tr>
          <th style="color: black">Other's Information</th>
          <td><textarea rows="5" cols="20" required id="otherInfo">okay info </textarea></td>
        </tr>
        <td height="50px" width="50px" colspan="2" align="right">
          <button type="button" onclick="submitRequest()" />
          Submit</button>
          <input type="reset" value="Reset" />
        </td>
      </table>
</body>
<table align="center">
  <tr>
    <p><br></p>
    <th><a style="color:white" href="index.php"> LOG OUT</a></th>
  </tr>

</table>

</head>

</html>