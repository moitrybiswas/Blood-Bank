<?php
$firstName=$_POST['fName'];
$lastName=$_POST['lName'];
$userName=$_POST['uName'];
$mail=$_POST['email'];
$mobileNumber=$_POST['mobile'];
$addressArea=$_POST['address'];
$countryName=$_POST['country'];
$gender=$_POST['uGender'];
$dateOfBirth=$_POST['DOB'];
$pass= $_POST['password'];
include 'connect.php';
$Myarray =  array();
$r=0;
$sql= "INSERT  INTO user_list
        VALUE('$userName','$firstName','$lastName','$pass','$mail','$gender','$mobileNumber','$countryName','$dateOfBirth');";
$result = mysqli_query($conn, $sql);
if ($result){
    $r = 1;
}
array_push($Myarray,$r);
echo json_encode($Myarray);

?>