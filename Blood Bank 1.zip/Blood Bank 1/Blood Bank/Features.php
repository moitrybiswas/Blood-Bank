<?php
      session_start();
      if(!isset($_SESSION['userName']) && empty($_SESSION['userName'])){
            echo $_SESSION['userName'];
          header('location: index.php');  
          exit();
      }
?>
<!DOCTYPE html>
<html>
<title>Blood Bank</title>

<head>
    <style>
        table,
        th,
        td {
            border-collapse: collapse;
            padding: 0px 20px 10px 10px;
        }
        
        .image {
            width: 500px;
            height: 250px;
            margin: 20px auto;
            box-sizing: border-box;
            overflow: hidden;
            /*box-shadow: 5px 5px 10px grey;*/
            padding-left: 30px;
        }
        
        a {
            color: white;
            font-weight: bold;
            font-size: 16px;
        }
    </style>

</head>

<body bgcolor="#424b5c">
    <h1 align="center" style="color: red;">Welcome Blood Bank</h1>

    <div class="image">
        <img src="index.jpg" width="450" height="200" align="center">
    </div>


    <table align="center">
        <tr>
            <td>
                <a href="Donor.php"> <img src="Donor.jpg" height="80px" width="120"></a>
                <p style="padding: 0px 0px 0px 20px"><a href="Donor.php">Be a Donor</p> 
		</td>
		<td>
			<a href="Find donor.php"> <img src="Find donor.jpg"  height="80px" width="120"></a>
                    <p style="padding: 0px 0px 0px 20px"><a href="Find donor.php">Find donor</p> 
			
		</td>
			<td>
			<a href="request.php"> <img src="request.jpg"  height="80px" width="120"></a>
                        <p><a href="request.php">  Request for Blood</a> </p>
            </td>
        </tr>
        <tr>
            <td>
                <a href="Blood Bank.php"> <img src="Blood Bank Number.jpg" height="80px" width="120" t></a>
                <p><a href="Blood Bank.php">Blood bank number</a> </p>
            </td>
            <td>
                <a href="Ambulance.php"> <img src="Ambulance.jpg" height="80px" width="120"></a>
                <p><a href="Ambulance.php"> Ambulance Number</a></p>
            </td>
            <td>
                <a href="Who can donate.html"> <img src="wcd.png" height="80px" width="120"></a>
                <p><a href="wcd.png"> Who can donate<br> to whom</a></p>
            </td>
        </tr>

        <table align="center">
            <tr>
                <p><br></p>
                <th><a href="Profile.php"> PROFILE</a></th>
                <th><a href="index.php"> LOG OUT</a></th>
            </tr>

        </table>
</body>

</html>