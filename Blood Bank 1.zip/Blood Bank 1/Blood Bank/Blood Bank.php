<?php
      session_start();
      if(!isset($_SESSION['userName']) && empty($_SESSION['userName'])){
            echo $_SESSION['userName'];
          header('location: index.php');  
          exit();
      }
?>
<!DOCTYPE html>
<htmj>
    <head>
        <title>Blood Bank</title>
        <link rel="stylesheet"href="./css/Style.css">
        <script src="script.js"></script>
        <style>
            table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 50%;
          background-color:white;
        
        }
        
        
        td, th {
          border: 1px solid brown;
          text-align: left;
          padding: 10px;
          color:brown;
        }
         
        #id01 tr:hover {background-color: #ddd;}
        
        </style>
        </head>
            <body bgcolor="#424b5c">
        
            <div  style="background-color: brown"style="border:solid black">
        
               <a href="Features.php"> <img src="imagehome.jpg"  height="100px" width="120" style="padding:0px 0px    0px 0px;"></a>
        
                    <a href="Donor.php"> <img src="Donor.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
                 
        
                    <a href="Find donor.php"> <img src="Find donor.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px; "></a>
                     
                    
                
                    <a href="request.php"> <img src="request.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
                   
                    <a href="Blood Bank.php"> <img src="Blood Bank Number.jpg"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>

              <a href="Ambulance.php"> <img src="Ambulance.jpg"  height="100px" width="120"style="padding:0px 0px 0px 90px;"></a>
                         
                
                 <a href="Who can donate.html"> <img src="wcd.png"  height="100px" width="120" style="padding:0px 0px 0px 90px;"></a>
                        
                    
            </div>
          
                     <h1 align="center" style="color: white">Blood Bank Numbers</h1>
        
          
        
        </head>
        <body>
          <form>
        <table align="center" id="id01">
          <tr>
            <th style="color: brown;">Name</th>
            <th style="color: brown;">Area</th>
            <th style="color: brown;">District</th>
            <th style="color: brown;">Contact</th>
          </tr>
          <?php
            require 'functions.php';
            $data = getBloodBankDetails();
            if (mysqli_num_rows($data) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($data)) {
                  echo "<tr>
                  <td >".$row["name"]."</td>
                  <td >".$row["area"]."</td>
                  <td >".$row["district"]."</td>
                  <td >".$row["contact_number"]."</td>
                  </tr>";
                }
              } 
        ?>
        </table>
        </form>
        
          <br>
        <br>
        <center>
          <tr>
            <th><a style="color:white" href="index.php"><b> LOG OUT</b></a></th>
          </tr>
          </center>
        
      </body>
        
        </html>
    </head>
</htmj>